return {
	"neovim/nvim-lspconfig",
	event = { "BufReadPre", "BufNewFile" },
	dependencies = {
		"hrsh7th/cmp-nvim-lsp", -- Completion for LSP
		{
			"antosha417/nvim-lsp-file-operations", -- File operations with LSP
			config = true,
		},
		"folke/trouble.nvim", -- Diagnostics UI
	},
	config = function()
		local lspconfig = require("lspconfig")
		local cmp_nvim_lsp = require("cmp_nvim_lsp")
		local keymap = vim.keymap
		local diagnostic = vim.diagnostic

		-- Optimize LSP capabilities for Clang
		local capabilities = cmp_nvim_lsp.default_capabilities()
		capabilities.textDocument.completion.completionItem.snippetSupport = true
		lspconfig.clangd.setup({
			cmd = {
				"clangd",
				"--query-driver=**/mingw64/bin/gcc.exe,**/mingw64/bin/g++.exe",
				-- Add these important flags
				"--header-insertion=iwyu",
				"--all-scopes-completion",
				"--suggest-missing-includes",
				"--clang-tidy",
			},
			capabilities = capabilities,
			-- Add include paths explicitly
			root_dir = lspconfig.util.root_pattern(
				".clangd",
				".clang-tidy",
				".clang-format",
				"compile_commands.json",
				"compile_flags.txt",
				"configure.ac",
				".git"
			),
			on_init = function(client)
				-- Explicitly set include paths for MinGW
				client.config.settings.init_options = {
					clangdFileStatus = true,
					usePlaceholders = true,
					completeUnimported = true,
					semanticTokens = true,
					-- Add your MinGW include paths here
					-- Adjust these paths to match your MinGW installation
					compilationDatabaseDirectory = vim.fn.expand("~/"),
					fallbackFlags = {
						"-I" .. vim.fn.expand("C:/ProgramData/mingw64/mingw64/include/c++/13.2.0"),
						"-I" .. vim.fn.expand("C:/ProgramData/mingw64/mingw64/include/c++/13.2.0/x86_64-w64-mingw32"),
						"-I" .. vim.fn.expand("C:/ProgramData/mingw64/mingw64/include/c++/13.2.0/backward"),
						"-I"
							.. vim.fn.expand("C:/ProgramData/mingw64/mingw64/lib/gcc/x86_64-w64-mingw32/13.2.0/include"),
						"-I" .. vim.fn.expand("C:/ProgramData/mingw64/mingw64/include"),
						"-I" .. vim.fn.expand("C:/ProgramData/mingw64/mingw64/x86_64-w64-mingw32/include"),
					},
				}
			end,
		})
		diagnostic.config({
			virtual_text = { prefix = "●" },
			signs = true,
			update_in_insert = false,
			severity_sort = true,
			float = {
				border = "rounded",
				source = "always",
				header = "",
				prefix = "",
			},
		})

		-- Global LSP keymappings
		vim.api.nvim_create_autocmd("LspAttach", {
			group = vim.api.nvim_create_augroup("UserLspConfig", { clear = true }),
			callback = function(ev)
				local opts = { buffer = ev.buf, silent = true }

				-- Optimize keymaps for quick navigation and actions
				keymap.set(
					"n",
					"gR",
					"<cmd>Telescope lsp_references<CR>",
					vim.tbl_extend("force", opts, { desc = "Show LSP references" })
				)
				keymap.set(
					"n",
					"gD",
					vim.lsp.buf.declaration,
					vim.tbl_extend("force", opts, { desc = "Go to declaration" })
				)
				keymap.set(
					"n",
					"gd",
					"<cmd>Telescope lsp_definitions<CR>",
					vim.tbl_extend("force", opts, { desc = "Show LSP definitions" })
				)
				keymap.set(
					"n",
					"gi",
					"<cmd>Telescope lsp_implementations<CR>",
					vim.tbl_extend("force", opts, { desc = "Show LSP implementations" })
				)
				keymap.set(
					{ "n", "v" },
					"<leader>ca",
					vim.lsp.buf.code_action,
					vim.tbl_extend("force", opts, { desc = "See available code actions" })
				)
				keymap.set(
					"n",
					"<leader>rn",
					vim.lsp.buf.rename,
					vim.tbl_extend("force", opts, { desc = "Smart rename" })
				)
				keymap.set(
					"n",
					"<leader>d",
					diagnostic.open_float,
					vim.tbl_extend("force", opts, { desc = "Show line diagnostics" })
				)
				keymap.set("n", "K", vim.lsp.buf.hover, vim.tbl_extend("force", opts, { desc = "Show documentation" }))

				-- Add Trouble.nvim integration for better diagnostics
				keymap.set(
					"n",
					"<leader>xx",
					"<cmd>TroubleToggle<cr>",
					vim.tbl_extend("force", opts, { desc = "Toggle Trouble diagnostics" })
				)
				keymap.set(
					"n",
					"<leader>xw",
					"<cmd>TroubleToggle workspace_diagnostics<cr>",
					vim.tbl_extend("force", opts, { desc = "Workspace diagnostics" })
				)
			end,
		})
	end,
}
