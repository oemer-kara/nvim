#include <iostream>

// TODO: This is a todo.
using namespace std;

int main() {
  std::cout << "Hello, World!" << std::endl;
  return 0;
}
