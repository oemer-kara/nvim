return {
  "rmagatti/auto-session",
  config = function()
    local auto_session = require("auto-session")

    auto_session.setup({
      auto_restore_enabled = true,           -- Automatically restore session on start
      auto_save_enabled = true,              -- Automatically save session on exit
      auto_session_suppress_dirs = { "~/", "~/Dev/", "~/Downloads", "~/Documents", "~/Desktop/" },  -- Suppress certain directories
    })

    local keymap = vim.keymap

    keymap.set("n", "<leader>wr", "<cmd>SessionRestore<CR>", { desc = "[R]estore Workspace" })
    keymap.set("n", "<leader>ws", "<cmd>SessionSave<CR>", { desc = "[S]ave Workspace" })
  end,
}
