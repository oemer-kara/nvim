return { "echasnovski/mini.nvim" }
